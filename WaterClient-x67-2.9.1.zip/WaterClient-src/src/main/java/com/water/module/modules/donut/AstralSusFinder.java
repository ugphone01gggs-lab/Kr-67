package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.ModeSetting;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Astral Sus Finder (banner AS) — scoring from AstralClient:
 * AMETHYST weight 1.2 cap 12, KELP ~1.0 cap 12, BAMBOO 0.6/15,
 * BERRIES 0.35/20, VINES 0.9/10, DRIPSTONE 0.4/15
 * + zone merge like Astral
 */
public final class AstralSusFinder extends Module {
   public static AstralSusFinder INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 5, 1, 20);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 8, 2, 20);
   public final Setting<Integer> mergeRadius = new Setting<>("Merge Radius", 2, 0, 6);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 100, -64, 320);
   public final ModeSetting heightMode = new ModeSetting("Marker Height", "Fixed Plane", "Fixed Plane", "At Finds");
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 90, 0, 255);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(120, 180, 255, 90));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> label = new Setting<>("Label", true);
   public final Setting<Boolean> smart = new Setting<>("Smart", true);

   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> kelp = new Setting<>("Kelp", true);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", true);
   public final Setting<Boolean> berries = new Setting<>("Berries", true);
   public final Setting<Boolean> vines = new Setting<>("Vines", true);
   public final Setting<Boolean> dripstone = new Setting<>("Dripstone", true);
   public final Setting<Integer> kelpMin = new Setting<>("Kelp Min Height", 8, 3, 25);
   public final Setting<Integer> bambooMin = new Setting<>("Bamboo Min Height", 10, 3, 16);
   public final Setting<Integer> vineMin = new Setting<>("Vine Min Length", 8, 3, 30);
   public final Setting<Integer> dripMin = new Setting<>("Drip Min Height", 5, 3, 20);

   // Astral Kind weights
   private static final double W_AM = 1.2;
   private static final double W_KELP = 1.0;
   private static final double W_BAM = 0.6;
   private static final double W_BER = 0.35;
   private static final double W_VIN = 0.9;
   private static final double W_DRIP = 0.4;
   private static final int CAP_AM = 12, CAP_KELP = 12, CAP_BAM = 15, CAP_BER = 20, CAP_VIN = 10, CAP_DRIP = 15;

   public static final class HitInfo {
      public final double score;
      public final String reasons;
      public final int percent;
      public final double findY;
      public HitInfo(double score, String reasons, int percent, double findY) {
         this.score = score;
         this.reasons = reasons;
         this.percent = percent;
         this.findY = findY;
      }
   }

   public volatile Map<ChunkPos, HitInfo> hits = Collections.emptyMap();
   private final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   public static final class LabelPos {
      public float x, y;
      public String reasons = "";
      public int percent;
      public long lastOkMs;
   }

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick, cursor;

   public AstralSusFinder() {
      super("Astral Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.mergeRadius);
      this.addSetting(this.renderY);
      this.addSetting(this.heightMode);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.fillColor);
      this.addSetting(this.outline);
      this.addSetting(this.label);
      this.addSetting(this.smart);
      this.addSetting(this.amethyst);
      this.addSetting(this.kelp);
      this.addSetting(this.bamboo);
      this.addSetting(this.berries);
      this.addSetting(this.vines);
      this.addSetting(this.dripstone);
      this.addSetting(this.kelpMin);
      this.addSetting(this.bambooMin);
      this.addSetting(this.vineMin);
      this.addSetting(this.dripMin);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "astral-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();
      final int merge = this.mergeRadius.getValue();
      final boolean smart = this.smart.getValue();
      final boolean doAm = this.amethyst.getValue();
      final boolean doKelp = this.kelp.getValue();
      final boolean doBam = this.bamboo.getValue();
      final boolean doBer = this.berries.getValue();
      final boolean doVin = this.vines.getValue();
      final boolean doDrip = this.dripstone.getValue();
      final int kelpMinH = this.kelpMin.getValue();
      final int bamMinH = this.bambooMin.getValue();
      final int vinMinH = this.vineMin.getValue();
      final int dripMinH = this.dripMin.getValue();

      // Astral-like threshold: sensitivity * ~1.0 mapped to score space
      final double threshold = sens * 1.0;

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;
      final World world = mc.world;

      final Map<ChunkPos, HitInfo> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, HitInfo> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, HitInfo> batchHits = new HashMap<>();
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               Score sc = scoreChunk(world, wc, cp, doAm, doKelp, doBam, doBer, doVin, doDrip,
                  kelpMinH, bamMinH, vinMinH, dripMinH);

               double need = threshold;
               if (smart) {
                  int sec = 0;
                  for (ChunkSection s : wc.getSectionArray()) {
                     if (s != null && !s.isEmpty()) sec++;
                  }
                  if (sec < 6) need *= 1.25;
                  if (sec < 3) need *= 1.4;
               }

               if (sc.score >= need && !sc.reasons.isEmpty()) {
                  float t = (float) ((sc.score - need) / Math.max(1.0, need * 2.0));
                  if (t < 0f) t = 0f;
                  if (t > 1f) t = 1f;
                  int pct = Math.round((0.55f + 0.45f * t) * 100f);
                  batchHits.put(cp, new HitInfo(sc.score, String.join("+", sc.reasons), pct, sc.findY));
               }
            }

            Map<ChunkPos, HitInfo> next = new HashMap<>(retained);
            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               HitInfo hi = batchHits.get(cp);
               if (hi != null) next.put(cp, hi);
               else next.remove(cp);
            }

            // Zone merge: if neighbour within mergeRadius also flagged, keep (already individual flags)
            // Optional: boost label when clustered
            if (merge > 0) {
               Set<ChunkPos> clustered = new HashSet<>();
               for (ChunkPos cp : next.keySet()) {
                  for (int dx = -merge; dx <= merge; dx++) {
                     for (int dz = -merge; dz <= merge; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        if (next.containsKey(new ChunkPos(cp.x + dx, cp.z + dz))) {
                           clustered.add(cp);
                        }
                     }
                  }
               }
               // re-tag clustered with ZONE hint in reasons (copy HitInfo)
               for (ChunkPos cp : clustered) {
                  HitInfo hi = next.get(cp);
                  if (hi != null && !hi.reasons.contains("ZONE")) {
                     next.put(cp, new HitInfo(hi.score, hi.reasons + "+ZONE", Math.min(100, hi.percent + 5), hi.findY));
                  }
               }
            }

            this.hits = Collections.unmodifiableMap(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private static final class Score {
      double score;
      double findY = 64;
      int findSamples;
      final List<String> reasons = new ArrayList<>();
      void add(String r, double w, int n, int cap, double y) {
         if (n <= 0) return;
         this.score += w * Math.min(n, cap);
         if (!this.reasons.contains(r)) this.reasons.add(r);
         this.findY = (this.findY * this.findSamples + y) / (this.findSamples + 1);
         this.findSamples++;
      }
   }

   private static Score scoreChunk(
         World world, WorldChunk chunk, ChunkPos cp,
         boolean doAm, boolean doKelp, boolean doBam, boolean doBer, boolean doVin, boolean doDrip,
         int kelpMinH, int bamMinH, int vinMinH, int dripMinH
   ) {
      Score sc = new Score();
      int am = 0, kelpN = 0, bamN = 0, berN = 0, vinN = 0, dripN = 0;
      double ySum = 0;
      int yN = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      BlockPos.Mutable mut2 = new BlockPos.Mutable();
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx, wy = baseY + ly, wz = z0 + lz;

                  if (doAm) {
                     if (b == Blocks.AMETHYST_CLUSTER) {
                        am += 2;
                        ySum += wy; yN++;
                        continue;
                     }
                     if (b == Blocks.BUDDING_AMETHYST || b == Blocks.AMETHYST_BLOCK) {
                        am += 1;
                        ySum += wy; yN++;
                        continue;
                     }
                     if (b == Blocks.LARGE_AMETHYST_BUD) {
                        am += 1;
                        continue;
                     }
                  }
                  if (doBer && b == Blocks.SWEET_BERRY_BUSH) {
                     if (st.contains(SweetBerryBushBlock.AGE) && st.get(SweetBerryBushBlock.AGE) >= 3) {
                        berN++;
                        ySum += wy; yN++;
                     }
                     continue;
                  }
                  if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.KELP) || above.isOf(Blocks.KELP_PLANT)) continue;
                     int h = colLen(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT);
                     boolean maxAge = b == Blocks.KELP && st.contains(Properties.AGE_25) && st.get(Properties.AGE_25) >= 20;
                     if (h >= kelpMinH || maxAge) {
                        kelpN++;
                        ySum += wy; yN++;
                     }
                     continue;
                  }
                  if (doBam && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.BAMBOO) || above.isOf(Blocks.BAMBOO_SAPLING)) continue;
                     int h = colLen(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING);
                     if (h >= bamMinH) {
                        bamN++;
                        ySum += wy; yN++;
                     }
                     continue;
                  }
                  if (doVin && (b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) {
                     mut.set(wx, wy - 1, wz);
                     BlockState below = world.getBlockState(mut);
                     if (below.isOf(Blocks.VINE) || below.isOf(Blocks.CAVE_VINES) || below.isOf(Blocks.CAVE_VINES_PLANT)) continue;
                     int h = colLen(world, mut2.set(wx, wy, wz), Direction.UP, Blocks.VINE, Blocks.CAVE_VINES, Blocks.CAVE_VINES_PLANT);
                     if (h >= vinMinH) {
                        vinN++;
                        ySum += wy; yN++;
                     }
                     continue;
                  }
                  if (doDrip && b == Blocks.POINTED_DRIPSTONE) {
                     mut.set(wx, wy + 1, wz);
                     if (world.getBlockState(mut).isOf(Blocks.POINTED_DRIPSTONE)) continue;
                     int h = colLen(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.POINTED_DRIPSTONE);
                     if (h >= dripMinH) {
                        dripN++;
                        ySum += wy; yN++;
                     }
                  }
               }
            }
         }
      }

      double fy = yN > 0 ? ySum / yN : 64;
      sc.add("AM", W_AM, am, CAP_AM, fy);
      sc.add("KELP", W_KELP, kelpN, CAP_KELP, fy);
      sc.add("BAM", W_BAM, bamN, CAP_BAM, fy);
      sc.add("BER", W_BER, berN, CAP_BER, fy);
      sc.add("VIN", W_VIN, vinN, CAP_VIN, fy);
      sc.add("DRIP", W_DRIP, dripN, CAP_DRIP, fy);
      if (yN > 0) sc.findY = fy;
      return sc;
   }

   private static int colLen(World world, BlockPos.Mutable pos, Direction dir, Block... match) {
      int n = 0;
      for (int i = 0; i < 32; i++) {
         BlockState st = world.getBlockState(pos);
         boolean ok = false;
         for (Block b : match) {
            if (st.isOf(b)) { ok = true; break; }
         }
         if (!ok) break;
         n++;
         pos.move(dir);
      }
      return n;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, HitInfo> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      boolean atFinds = this.heightMode.is("At Finds");
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         double plane = atFinds ? e.getValue().findY : this.renderY.getValue();
         double y = plane - cam.y;
         double y2 = y + 0.25;
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      AstralSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.label.getValue()) return;
      Map<ChunkPos, HitInfo> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      boolean atFinds = self.heightMode.is("At Finds");
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();

      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         HitInfo hi = e.getValue();
         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.reasons = hi.reasons;
         lp.percent = hi.percent;
         double textY = (atFinds ? hi.findY : self.renderY.getValue()) + 1.8;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 250L && lp.lastOkMs > 0) {
            String tag = "AS";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            float ty = lp.y - 24f;
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f, ty, 0xFF78B4FF);
            if (lp.reasons != null && !lp.reasons.isEmpty()) {
               int rw = FontRenderer.INSTANCE.getWidth(lp.reasons);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f + 1, ty + 11, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f, ty + 10, 0xFFB8D8FF);
            }
            String pct = lp.percent + "%";
            int pw = FontRenderer.INSTANCE.getWidth(pct);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, ty + 21, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, ty + 20, 0xFFB8D8FF);
         }
      }
      self.labelCache.keySet().removeIf(c -> !keep.contains(c));
   }
}
