package com.water.module.modules.donut;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

/**
 * Packet-driven light cache for Donut-style lazy loading.
 * LightUpdate / ChunkData packets mark chunks dirty; we sample block light
 * and keep sticky values so Sus can use light even when blocks are not fully loaded.
 */
public final class ServerLightCache {
   public static final ServerLightCache INSTANCE = new ServerLightCache();
   public static final int SCAN_Y_MIN = -60;
   public static final int SCAN_Y_MAX = 64;
   /** How long a packet-backed sample stays trusted without a new packet (ms). */
   public static final long STICKY_MS = 120_000L;

   private final Map<Long, Integer> light5Count = new ConcurrentHashMap<>();
   /** Softer band light 4–6 (room / cave lighting anomalies). */
   private final Map<Long, Integer> softLightCount = new ConcurrentHashMap<>();
   private final Map<Long, Long> lastPacketMs = new ConcurrentHashMap<>();
   private final Map<Long, Long> lastSampleMs = new ConcurrentHashMap<>();
   private final Set<Long> dirty = ConcurrentHashMap.newKeySet();

   private ServerLightCache() {}

   public void clear() {
      this.light5Count.clear();
      this.softLightCount.clear();
      this.lastPacketMs.clear();
      this.lastSampleMs.clear();
      this.dirty.clear();
   }

   public void onLightPacket(int chunkX, int chunkZ) {
      long k = ChunkPos.toLong(chunkX, chunkZ);
      this.dirty.add(k);
      this.lastPacketMs.put(k, System.currentTimeMillis());
   }

   public void flushDirty(MinecraftClient mc) {
      if (mc == null || mc.world == null || this.dirty.isEmpty()) return;
      World world = mc.world;
      BlockPos.Mutable mut = new BlockPos.Mutable();
      List<Long> batch = new ArrayList<>(Math.min(12, this.dirty.size()));
      int n = 0;
      for (Long key : this.dirty) {
         if (n >= 10) break;
         batch.add(key);
         n++;
      }
      for (Long key : batch) this.dirty.remove(key);

      long now = System.currentTimeMillis();
      for (Long key : batch) {
         ChunkPos cp = new ChunkPos(key);
         Sample s = sampleLights(world, cp.x, cp.z, mut);
         long k = ChunkPos.toLong(cp.x, cp.z);
         this.lastSampleMs.put(k, now);
         // sticky: never drop a previous positive sample to zero on one empty pass
         // (Donut often samples before light is fully applied)
         if (s.exact5 > 0) {
            this.light5Count.put(k, s.exact5);
         } else {
            Integer prev = this.light5Count.get(k);
            if (prev == null || prev <= 0) this.light5Count.remove(k);
            // keep prev if packet was recent
         }
         if (s.soft > 0) {
            this.softLightCount.put(k, s.soft);
         } else {
            Integer prev = this.softLightCount.get(k);
            if (prev == null || prev <= 0) this.softLightCount.remove(k);
         }
      }
   }

   private static final class Sample {
      int exact5;
      int soft;
   }

   private static Sample sampleLights(World world, int chunkX, int chunkZ, BlockPos.Mutable mut) {
      Sample s = new Sample();
      int x0 = chunkX << 4;
      int z0 = chunkZ << 4;
      // denser sample after packet (step 1 on Y every 2 was sparse)
      for (int y = SCAN_Y_MIN; y <= SCAN_Y_MAX; y += 1) {
         for (int x = 0; x < 16; x += 2) {
            for (int z = 0; z < 16; z += 2) {
               mut.set(x0 + x, y, z0 + z);
               if (!world.isChunkLoaded(mut)) continue;
               int lv = world.getLightLevel(LightType.BLOCK, mut);
               if (lv == 5) s.exact5++;
               if (lv >= 4 && lv <= 6) s.soft++;
            }
         }
      }
      return s;
   }

   public int getLight5Count(ChunkPos cp) {
      return getSticky(this.light5Count, cp);
   }

   public int getSoftLightCount(ChunkPos cp) {
      return getSticky(this.softLightCount, cp);
   }

   /** True if we received a light/chunk packet for this chunk recently. */
   public boolean hasRecentPacket(ChunkPos cp, long maxAgeMs) {
      Long t = this.lastPacketMs.get(ChunkPos.toLong(cp.x, cp.z));
      if (t == null) return false;
      return System.currentTimeMillis() - t <= maxAgeMs;
   }

   public boolean hasAnyCachedLight(ChunkPos cp) {
      return getLight5Count(cp) > 0 || getSoftLightCount(cp) > 0;
   }

   private int getSticky(Map<Long, Integer> map, ChunkPos cp) {
      long k = ChunkPos.toLong(cp.x, cp.z);
      Integer v = map.get(k);
      if (v == null || v <= 0) return 0;
      Long sampled = this.lastSampleMs.get(k);
      Long packet = this.lastPacketMs.get(k);
      long now = System.currentTimeMillis();
      // expire very old data without new packets
      long ref = 0L;
      if (sampled != null) ref = Math.max(ref, sampled);
      if (packet != null) ref = Math.max(ref, packet);
      if (ref > 0 && now - ref > STICKY_MS) {
         map.remove(k);
         return 0;
      }
      return v;
   }
}
