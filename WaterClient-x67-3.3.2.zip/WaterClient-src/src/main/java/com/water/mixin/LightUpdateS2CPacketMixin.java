package com.water.mixin;

import com.water.module.modules.donut.ServerLightCache;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LightUpdateS2CPacket.class)
public class LightUpdateS2CPacketMixin {
   @Inject(method = "apply", at = @At("TAIL"), require = 0)
   private void water$onLightUpdate(CallbackInfo ci) {
      try {
         LightUpdateS2CPacket self = (LightUpdateS2CPacket) (Object) this;
         ServerLightCache.INSTANCE.onLightPacket(self.getChunkX(), self.getChunkZ());
      } catch (Throwable ignored) {
      }
   }
}
