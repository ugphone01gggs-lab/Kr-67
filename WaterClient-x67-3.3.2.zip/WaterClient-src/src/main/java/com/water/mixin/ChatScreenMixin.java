package com.water.mixin;

import com.water.gui.HudEditor;
import com.water.gui.SpotifyOverlay;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ChatScreen.class})
public class ChatScreenMixin {
   public ChatScreenMixin() {
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void water$mouseClicked(Click click, boolean var2, CallbackInfoReturnable<Boolean> cir) {
      try {
         if (click == null) return;
         double d0 = click.x();
         double d1 = click.y();
         int i = click.button();
         if (i == 0) {
            if (SpotifyOverlay.handleClick(d0, d1, i)) {
               cir.setReturnValue(true);
               return;
            }
            if (HudEditor.INSTANCE != null && HudEditor.INSTANCE.onMouseClick(d0, d1, i)) {
               HudEditor.isEditing = true;
               cir.setReturnValue(true);
            }
         }
      } catch (Throwable ignored) {
         // never crash chat on HUD overlay errors
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")},
      require = 0
   )
   private void water$render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc == null || mc.getWindow() == null) return;
         boolean held = false;
         try {
            held = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0) == 1;
         } catch (Throwable ignored) {
         }
         if (!held) {
            try {
               SpotifyOverlay.stopDragging();
            } catch (Throwable ignored) {
            }
            if (HudEditor.INSTANCE != null) {
               HudEditor.INSTANCE.onMouseRelease();
            }
            HudEditor.isEditing = false;
         }
         if (context != null && HudEditor.INSTANCE != null) {
            HudEditor.INSTANCE.render(context, mouseX, mouseY);
         }
      } catch (Throwable ignored) {
      }
   }
}
