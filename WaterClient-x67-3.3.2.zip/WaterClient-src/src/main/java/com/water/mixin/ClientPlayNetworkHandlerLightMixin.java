package com.water.mixin;

import com.water.module.modules.donut.ServerLightCache;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerLightMixin {
   @Inject(method = "onLightUpdate", at = @At("TAIL"), require = 0)
   private void water$lightUpdate(LightUpdateS2CPacket packet, CallbackInfo ci) {
      try {
         ServerLightCache.INSTANCE.onLightPacket(packet.getChunkX(), packet.getChunkZ());
      } catch (Throwable ignored) {
      }
   }

   @Inject(method = "onChunkData", at = @At("TAIL"), require = 0)
   private void water$chunkData(ChunkDataS2CPacket packet, CallbackInfo ci) {
      try {
         ServerLightCache.INSTANCE.onLightPacket(packet.getChunkX(), packet.getChunkZ());
      } catch (Throwable ignored) {
      }
   }
}
