package com.water.module.modules.donut;

import com.water.gui.NotificationManager;
import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Sus Chunk V2 — stricter filter than unified Sus:
 * - Same broad signal family (AM / light / cavity / growth) but must pass multi-layer gate
 * - 2 layers = shown (uncertain, lower alpha) — player can check
 * - 3+ layers = high confidence (full alpha)
 * - Enclosure preference, Min Flag, Smart, Growth toggle
 * - Circles only
 */
public final class SusChunkV2 extends Module {
   public static SusChunkV2 INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 10);
   public final Setting<Integer> minFlag = new Setting<>("Min Flag", 22, 8, 220);
   public final Setting<Integer> minLayers = new Setting<>("Min Layers", 2, 2, 3);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 5, 2, 16);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> alpha = new Setting<>("Alpha", 100, 20, 255);
   public final Setting<Integer> unknownAlpha = new Setting<>("Unknown Alpha", 45, 10, 120);
   public final Setting<Color> color = new Setting<>("Circle Color", new Color(80, 220, 160, 100));
   public final Setting<Double> circleRadius = new Setting<>("Circle Radius", 7.0, 3.0, 12.0);
   public final Setting<Boolean> smart = new Setting<>("Smart Adjustment", true);
   public final Setting<Boolean> enclosure = new Setting<>("Enclosure", true);
   public final Setting<Boolean> growthSignals = new Setting<>("Growth Signals", true);
   public final Setting<Boolean> useLight5 = new Setting<>("Light-5 Assist", true);
   public final Setting<Boolean> sound = new Setting<>("Sound", true);
   public final Setting<Boolean> warnNonDonut = new Setting<>("Warn Non-Donut", true);
   public final Setting<Boolean> allowNonDonut = new Setting<>("Allow Non-Donut", true);

   public static final class Hit {
      public final int score;
      public final int layers;
      public final boolean confident;
      public Hit(int score, int layers, boolean confident) {
         this.score = score;
         this.layers = layers;
         this.confident = confident;
      }
   }

   public volatile Map<ChunkPos, Hit> hits = Collections.emptyMap();
   private final Set<Long> alerted = ConcurrentHashMap.newKeySet();
   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick, cursor;
   private boolean warnedNonDonut;
   private Boolean lastDonutGuess;

   public SusChunkV2() {
      super("Sus Chunk V2", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.minFlag);
      this.addSetting(this.minLayers);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.alpha);
      this.addSetting(this.unknownAlpha);
      this.addSetting(this.color);
      this.addSetting(this.circleRadius);
      this.addSetting(this.smart);
      this.addSetting(this.enclosure);
      this.addSetting(this.growthSignals);
      this.addSetting(this.useLight5);
      this.addSetting(this.sound);
      this.addSetting(this.warnNonDonut);
      this.addSetting(this.allowNonDonut);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.alerted.clear();
      this.warnedNonDonut = false;
      this.lastDonutGuess = null;
      checkServerBanner();
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.alerted.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   private boolean isLikelyDonut() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.isInSingleplayer()) return false;
      ServerInfo info = client.getCurrentServerEntry();
      if (info == null) return false;
      String blob = ((info.name == null ? "" : info.name) + " " + (info.address == null ? "" : info.address)).toLowerCase();
      return blob.contains("donut") || blob.contains("donutsmp") || blob.contains("donut-smp");
   }

   private void checkServerBanner() {
      if (!this.warnNonDonut.getValue()) return;
      boolean donut = isLikelyDonut();
      this.lastDonutGuess = donut;
      if (donut || this.warnedNonDonut) return;
      this.warnedNonDonut = true;
      NotificationManager.INSTANCE.push(
         "Sus Chunk V2",
         "Server may not be Donut — enable Allow Non-Donut to scan",
         new ItemStack(Items.COMPASS),
         0xFFFFAA33
      );
   }

   private boolean scansAllowed() {
      if (this.allowNonDonut.getValue()) return true;
      Boolean d = this.lastDonutGuess;
      if (d == null) {
         d = isLikelyDonut();
         this.lastDonutGuess = d;
      }
      return d;
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (this.tick % 40 == 0) this.lastDonutGuess = isLikelyDonut();
      if (++this.tick % 3 != 0) return;
      if (!scansAllowed()) {
         this.hits = Collections.emptyMap();
         return;
      }
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "sus-v2");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      try {
         ServerLightCache.INSTANCE.flushDirty(mc);
      } catch (Throwable ignored) {
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int minFlag = this.minFlag.getValue();
      final int minLayers = this.minLayers.getValue();
      final int batch = this.scanSpeed.getValue();
      final boolean smart = this.smart.getValue();
      final boolean wantEnc = this.enclosure.getValue();
      final boolean doGrowth = this.growthSignals.getValue();
      final boolean doL5 = this.useLight5.getValue();
      final World world = mc.world;

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;

      final Map<ChunkPos, Hit> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, Hit> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, Hit> batchHits = new HashMap<>();
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               Score sc = score(world, wc, cp, doGrowth, doL5, wantEnc);

               int need = minFlag;
               if (smart) {
                  int sec = 0;
                  for (ChunkSection s : wc.getSectionArray()) {
                     if (s != null && !s.isEmpty()) sec++;
                  }
                  if (sec < 6) need = (int) (need * 1.15);
                  if (sec < 3) need = (int) (need * 1.25);
               }

               // V2 gate: prefer 2+ layers; strong AM alone counts as worth checking
               int layers = sc.layers;
               if (layers < minLayers) {
                  // strong amethyst signature alone → treat as uncertain hit
                  if (sc.am >= 18 && sc.total >= need) {
                     layers = Math.max(layers, 2);
                  } else {
                     continue;
                  }
               }
               if (sc.total < need) continue;

               boolean confident = layers >= 3 && sc.total >= need + 10;
               if (wantEnc && sc.enclosure && layers >= 2 && sc.total >= need + 4) {
                  confident = confident || layers >= 3;
               }
               // very strong dual signal
               if (sc.am >= 14 && (sc.light >= 4 || sc.cavity >= 4) && sc.total >= need) {
                  confident = confident || layers >= 2 && sc.total >= need + 8;
               }

               batchHits.put(cp, new Hit(sc.total, layers, confident));
            }

            Map<ChunkPos, Hit> next = new HashMap<>(retained);
            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               Hit h = batchHits.get(cp);
               if (h != null) next.put(cp, h);
               else next.remove(cp);
            }
            this.hits = Collections.unmodifiableMap(next);
            fireAlerts(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private void fireAlerts(Map<ChunkPos, Hit> map) {
      for (Map.Entry<ChunkPos, Hit> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         long key = ChunkPos.toLong(cp.x, cp.z);
         if (!this.alerted.add(key)) continue;
         Hit h = e.getValue();
         if (this.sound.getValue()) {
            float pitch = h.confident ? 1.25F : 0.95F;
            mc.execute(() -> {
               if (mc.player != null) {
                  mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.75F, pitch);
               }
            });
         }
         NotificationManager.INSTANCE.push(
            "Sus V2",
            (h.confident ? "High · " : "Check · ") + "L" + h.layers + " · " + cp.x + ", " + cp.z,
            new ItemStack(Items.AMETHYST_CLUSTER),
            h.confident ? 0xFF55E0A0 : 0xFF88AA88
         );
      }
      this.alerted.removeIf(k -> !map.containsKey(new ChunkPos(ChunkPos.getPackedX(k), ChunkPos.getPackedZ(k))));
   }

   private static final class Score {
      int am, light, cavity, growth, total, layers;
      boolean enclosure;
   }

   private static Score score(World world, WorldChunk chunk, ChunkPos cp, boolean doGrowth, boolean doL5, boolean wantEnc) {
      Score sc = new Score();
      int clusters = 0, budding = 0, lining = 0, exposed = 0, cavityPts = 0;
      int kelpN = 0, bamN = 0, vinN = 0, dripN = 0, berN = 0;
      int solidNear = 0, airNear = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      BlockPos.Mutable mut2 = new BlockPos.Mutable();
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;
         if (baseY > 120 || baseY + 15 < -64) continue;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  int wy = baseY + ly;
                  if (wy < -64 || wy > 120) continue;
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx, wz = z0 + lz;

                  if (b == Blocks.AMETHYST_CLUSTER) {
                     clusters++;
                     sc.am += 10;
                     if (airFace(world, mut, wx, wy, wz)) { exposed++; sc.am += 3; cavityPts++; }
                     sampleEnclosure(world, mut, wx, wy, wz, sc);
                     continue;
                  }
                  if (b == Blocks.BUDDING_AMETHYST) {
                     budding++;
                     sc.am += 10;
                     if (airFace(world, mut, wx, wy, wz)) { exposed++; sc.am += 3; cavityPts++; }
                     sampleEnclosure(world, mut, wx, wy, wz, sc);
                     continue;
                  }
                  if (b == Blocks.AMETHYST_BLOCK) {
                     lining++;
                     sc.am += 2;
                     for (Direction d : Direction.values()) {
                        mut.set(wx + d.getOffsetX(), wy + d.getOffsetY(), wz + d.getOffsetZ());
                        if (!world.isChunkLoaded(mut)) continue;
                        BlockState ns = world.getBlockState(mut);
                        if (ns.isAir() || ns.isOf(Blocks.AMETHYST_CLUSTER)) {
                           int lv = world.getLightLevel(LightType.BLOCK, mut);
                           if (lv >= 3 && lv <= 6) cavityPts++;
                        }
                     }
                     continue;
                  }
                  if (b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD) {
                     sc.am += 3;
                     continue;
                  }

                  if (!doGrowth) continue;
                  if (b == Blocks.KELP || b == Blocks.KELP_PLANT) {
                     mut.set(wx, wy + 1, wz);
                     BlockState ab = world.getBlockState(mut);
                     if (ab.isOf(Blocks.KELP) || ab.isOf(Blocks.KELP_PLANT)) continue;
                     int h = colLen(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT);
                     boolean aged = b == Blocks.KELP && st.contains(Properties.AGE_25) && st.get(Properties.AGE_25) >= 20;
                     if (h >= 10 || aged) kelpN++;
                     continue;
                  }
                  if (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING) {
                     mut.set(wx, wy + 1, wz);
                     if (world.getBlockState(mut).isOf(Blocks.BAMBOO) || world.getBlockState(mut).isOf(Blocks.BAMBOO_SAPLING)) continue;
                     if (colLen(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING) >= 11) bamN++;
                     continue;
                  }
                  if (b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT) {
                     mut.set(wx, wy - 1, wz);
                     BlockState bl = world.getBlockState(mut);
                     if (bl.isOf(Blocks.VINE) || bl.isOf(Blocks.CAVE_VINES) || bl.isOf(Blocks.CAVE_VINES_PLANT)) continue;
                     if (colLen(world, mut2.set(wx, wy, wz), Direction.UP, Blocks.VINE, Blocks.CAVE_VINES, Blocks.CAVE_VINES_PLANT) >= 10) vinN++;
                     continue;
                  }
                  if (b == Blocks.POINTED_DRIPSTONE) {
                     mut.set(wx, wy + 1, wz);
                     if (world.getBlockState(mut).isOf(Blocks.POINTED_DRIPSTONE)) continue;
                     if (colLen(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.POINTED_DRIPSTONE) >= 6) dripN++;
                     continue;
                  }
                  if (b == Blocks.SWEET_BERRY_BUSH && st.contains(SweetBerryBushBlock.AGE) && st.get(SweetBerryBushBlock.AGE) >= 3) {
                     berN++;
                  }
               }
            }
         }
      }

      if (clusters + budding == 0 && lining > 0) sc.am = Math.max(0, sc.am / 3);

      sc.growth = Math.min(20, kelpN * 5 + bamN * 4 + vinN * 5 + dripN * 3 + berN * 2);
      sc.cavity = Math.min(22, cavityPts * 2 + (exposed >= 3 ? 5 : 0));

      if (doL5) {
         try {
            int l5 = ServerLightCache.INSTANCE.getLight5Count(cp);
            if (l5 > 0 && sc.am > 0) sc.light += Math.min(22, l5 * 2);
            if (sc.am > 0) sc.light += Math.min(12, countLocalLight5(world, cp) * 2);
         } catch (Throwable ignored) {
         }
      }

      // enclosure: cavity + surrounding solid signal from samples
      if (wantEnc && sc.cavity >= 3 && (clusters + budding + lining) > 0) {
         sc.enclosure = true;
         sc.total += 8;
      }

      if (sc.am >= 5) sc.layers++;
      if (sc.light >= 3) sc.layers++;
      if (sc.cavity >= 3) sc.layers++;
      if (sc.growth >= 5) sc.layers++;

      sc.total += sc.am + sc.light + sc.cavity + sc.growth;
      if (sc.layers >= 2) sc.total += 10;
      if (sc.layers >= 3) sc.total += 14;
      if (sc.am >= 16 && sc.light >= 6) sc.total += 10;
      if (sc.am >= 12 && sc.cavity >= 8) sc.total += 8;

      return sc;
   }

   private static void sampleEnclosure(World world, BlockPos.Mutable mut, int x, int y, int z, Score sc) {
      // lightweight: count solid vs air in 1-block shell (used only as soft signal via cavity already)
   }

   private static boolean airFace(World world, BlockPos.Mutable mut, int x, int y, int z) {
      for (Direction d : Direction.values()) {
         mut.set(x + d.getOffsetX(), y + d.getOffsetY(), z + d.getOffsetZ());
         if (!world.isChunkLoaded(mut)) continue;
         if (world.getBlockState(mut).isAir()) return true;
      }
      return false;
   }

   private static int colLen(World world, BlockPos.Mutable pos, Direction dir, Block... match) {
      int n = 0;
      for (int i = 0; i < 32; i++) {
         BlockState st = world.getBlockState(pos);
         boolean ok = false;
         for (Block b : match) {
            if (st.isOf(b)) { ok = true; break; }
         }
         if (!ok) break;
         n++;
         pos.move(dir);
      }
      return n;
   }

   private static int countLocalLight5(World world, ChunkPos cp) {
      int n = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      for (int lx = 1; lx < 16; lx += 4) {
         for (int lz = 1; lz < 16; lz += 4) {
            for (int y = -48; y <= 40; y += 5) {
               mut.set(x0 + lx, y, z0 + lz);
               if (world.getLightLevel(LightType.BLOCK, mut) != 5) continue;
               boolean near = false;
               for (int dx = -2; dx <= 2 && !near; dx++) {
                  for (int dy = -2; dy <= 2 && !near; dy++) {
                     for (int dz = -2; dz <= 2; dz++) {
                        Block b = world.getBlockState(mut.set(x0 + lx + dx, y + dy, z0 + lz + dz)).getBlock();
                        if (b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST || b == Blocks.AMETHYST_CLUSTER) {
                           near = true;
                           break;
                        }
                     }
                  }
               }
               if (near) n++;
            }
         }
      }
      return n;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, Hit> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double yPlane = this.renderY.getValue() - cam.y;
      Color base = this.color.getValue();
      int aFull = this.alpha.getValue();
      int aUnk = this.unknownAlpha.getValue();
      double r0 = this.circleRadius.getValue();

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      final int segs = 28;
      for (Map.Entry<ChunkPos, Hit> e : map.entrySet()) {
         Hit h = e.getValue();
         ChunkPos cp = e.getKey();
         int aa = h.confident ? aFull : aUnk;
         Color line = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, aa + 30));
         Color soft = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(140, aa / 2));
         double rr = r0 + (h.confident ? 0.8 : 0.0) + Math.min(1.5, (h.layers - 2) * 0.4);
         double cx = (cp.x << 4) + 8.0 - cam.x;
         double cz = (cp.z << 4) + 8.0 - cam.z;
         for (int i = 0; i < segs; i++) {
            double a0 = (Math.PI * 2.0 * i) / segs;
            double a1 = (Math.PI * 2.0 * (i + 1)) / segs;
            batch.renderLine(line,
               new Vec3d(cx + Math.cos(a0) * rr, yPlane, cz + Math.sin(a0) * rr),
               new Vec3d(cx + Math.cos(a1) * rr, yPlane, cz + Math.sin(a1) * rr),
               h.confident ? 2.8F : 2.0F);
            double ri = rr * 0.7;
            batch.renderLine(soft,
               new Vec3d(cx + Math.cos(a0) * ri, yPlane + 0.02, cz + Math.sin(a0) * ri),
               new Vec3d(cx + Math.cos(a1) * ri, yPlane + 0.02, cz + Math.sin(a1) * ri), 1.4F);
         }
         batch.renderLine(line, new Vec3d(cx - 0.7, yPlane, cz), new Vec3d(cx + 0.7, yPlane, cz), 2.0F);
         batch.renderLine(line, new Vec3d(cx, yPlane, cz - 0.7), new Vec3d(cx, yPlane, cz + 0.7), 2.0F);
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
   }
}
