package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.ModeSetting;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * 67 Sus Chunk Finder — improved:
 * - Mode: Donut (light+amethyst), Classic (all growth), Aggressive
 * - Stable hits (anti-flicker)
 * - Reason tags on labels (AM/L5/KELP/...)
 * - Weighted scoring closer to 67
 */
public final class SUSChunkFinder extends Module {
   public static SUSChunkFinder INSTANCE;
   public static final int POINTS_PER_SENSITIVITY = 5;

   public final ModeSetting mode = new ModeSetting("Mode", "Donut", "Donut", "Classic", "Aggressive");
   public final Setting<Integer> simulationDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 6, 1, 20);
   public final Setting<Boolean> smartMode = new Setting<>("Smart Mode", true);
   public final Setting<Integer> stableHits = new Setting<>("Stable Hits", 2, 1, 5);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 8, 2, 24);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 55, 0, 255);
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 50, 50, 55));
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);
   public final Setting<Boolean> showReason = new Setting<>("Show Reason", true);

   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> kelp = new Setting<>("Kelp", false);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", false);
   public final Setting<Boolean> berries = new Setting<>("Berries", false);
   public final Setting<Boolean> vines = new Setting<>("Vines", false);
   public final Setting<Boolean> dripstone = new Setting<>("Dripstone", false);
   public final Setting<Boolean> light5 = new Setting<>("Light-5 Amethyst", true);
   public final Setting<Integer> minLight5 = new Setting<>("Min Light-5 Cells", 10, 1, 64);
   public final Setting<Integer> minKelpHeight = new Setting<>("Min Kelp Height", 8, 3, 25);
   public final Setting<Integer> minBambooHeight = new Setting<>("Min Bamboo Height", 10, 3, 16);

   /** Published hits after stability filter */
   public volatile Map<ChunkPos, HitInfo> hits = Collections.emptyMap();
   public volatile int lastThreshold = 30;

   public static final class HitInfo {
      public final double score;
      public final String reasons;
      public final int percent;

      public HitInfo(double score, String reasons, int percent) {
         this.score = score;
         this.reasons = reasons;
         this.percent = percent;
      }
   }

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public String reasons = "";
      public long lastOkMs;
   }

   /** Internal: consecutive pass counts for anti-flicker */
   private final Map<ChunkPos, Integer> streak = new ConcurrentHashMap<>();
   private final Map<ChunkPos, Long> lastSeenMs = new ConcurrentHashMap<>();
   private final Map<ChunkPos, HitInfo> pending = new ConcurrentHashMap<>();

   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   private ExecutorService scanExec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tickCount = 0;
   private int scanCursor = 0;

   public SUSChunkFinder() {
      super("67 Sus Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.mode);
      this.addSetting(this.simulationDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.smartMode);
      this.addSetting(this.stableHits);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.outline);
      this.addSetting(this.fillColor);
      this.addSetting(this.showPercent);
      this.addSetting(this.showReason);
      this.addSetting(this.amethyst);
      this.addSetting(this.kelp);
      this.addSetting(this.bamboo);
      this.addSetting(this.berries);
      this.addSetting(this.vines);
      this.addSetting(this.dripstone);
      this.addSetting(this.light5);
      this.addSetting(this.minLight5);
      this.addSetting(this.minKelpHeight);
      this.addSetting(this.minBambooHeight);
   }

   public static int confidencePercent(double score, int threshold) {
      if (threshold <= 0) return 100;
      float t = (float) ((score - threshold) / (threshold * 2.0));
      if (t < 0f) t = 0f;
      if (t > 1f) t = 1f;
      return Math.round((0.55f + 0.45f * t) * 100f);
   }

   private void applyModeDefaults() {
      // Soft defaults when mode changes — user can still override toggles
      String m = this.mode.getValue();
      if ("Donut".equalsIgnoreCase(m)) {
         // prefer light + amethyst only for Donut anti-xray world
      } else if ("Aggressive".equalsIgnoreCase(m)) {
         // allow more signals in aggressive
      }
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.streak.clear();
      this.pending.clear();
      this.lastSeenMs.clear();
      this.tickCount = 0;
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      SusAlert.clear("67");
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.streak.clear();
      this.pending.clear();
      this.lastSeenMs.clear();
      this.scanning.set(false);
      if (this.scanExec != null) {
         this.scanExec.shutdownNow();
         this.scanExec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;

      ServerLightCache.INSTANCE.flushDirty(mc);

      if (++this.tickCount % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.scanExec == null || this.scanExec.isShutdown()) {
         this.scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "67-sus-scan");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simulationDist.getValue();
      final double threshold = this.sensitivity.getValue() * (double) POINTS_PER_SENSITIVITY;
      final boolean smart = this.smartMode.getValue();
      final int batch = this.scanSpeed.getValue();
      final int needStable = this.stableHits.getValue();
      final String modeName = this.mode.getValue();

      final boolean donutMode = modeName.equalsIgnoreCase("Donut");
      final boolean aggressive = modeName.equalsIgnoreCase("Aggressive");

      // Mode gates which signals run (user toggles still apply as AND)
      final boolean doAm = this.amethyst.getValue();
      final boolean doKelp = !donutMode && this.kelp.getValue();
      final boolean doBamboo = !donutMode && this.bamboo.getValue();
      final boolean doBerries = !donutMode && this.berries.getValue();
      final boolean doVines = aggressive && this.vines.getValue();
      final boolean doDrip = !donutMode && this.dripstone.getValue();
      final boolean doLight5 = this.light5.getValue() && doAm;
      final int minL5 = this.minLight5.getValue();
      final int minKelpH = this.minKelpHeight.getValue();
      final int minBambooH = this.minBambooHeight.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.scanCursor % positions.size();
      this.scanCursor = start + batch;

      final Map<ChunkPos, Integer> lightSnap = new HashMap<>();
      if (doLight5) {
         for (ChunkPos cp : positions) {
            int c = ServerLightCache.INSTANCE.getLight5Count(cp);
            if (c > 0) lightSnap.put(cp, c);
         }
      }

      final World world = mc.world;
      final Set<ChunkPos> inRange = new HashSet<>(positions);

      this.scanExec.submit(() -> {
         try {
            Map<ChunkPos, HitInfo> rawThisBatch = new HashMap<>();
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            int usedTh = (int) Math.round(threshold);

            for (int idx : idxs) {
               if (idx < 0 || idx >= positions.size()) continue;
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);

               ScanResult sr = scoreChunk(
                  world, wc, cp, doAm, doKelp, doBamboo, doBerries, doVines, doDrip,
                  minKelpH, minBambooH);

               int l5 = lightSnap.getOrDefault(cp, 0);
               if (doLight5 && l5 >= minL5) {
                  sr.score += Math.min(l5, 16) * 6.0;
                  sr.addReason("L5");
               }

               double need = threshold;
               if (smart) {
                  int sec = 0;
                  for (ChunkSection s : wc.getSectionArray()) {
                     if (s != null && !s.isEmpty()) sec++;
                  }
                  if (sec < 6) need *= 1.2;
                  if (sec < 3) need *= 1.4;
               }
               // Donut mode: slightly higher bar for pure amethyst lining without L5
               if (donutMode && !sr.reasons.contains("L5") && sr.reasons.contains("AM")) {
                  need *= 1.15;
               }

               if (sr.score >= need && !sr.reasons.isEmpty()) {
                  int pct = confidencePercent(sr.score, usedTh);
                  rawThisBatch.put(cp, new HitInfo(sr.score, sr.reasonString(), pct));
               }
            }

            // Update streak / pending with this batch results
            for (ChunkPos cp : idxs.stream().filter(i -> i >= 0 && i < positions.size()).map(positions::get).toList()) {
               HitInfo hi = rawThisBatch.get(cp);
               if (hi != null) {
                  this.pending.put(cp, hi);
                  this.streak.merge(cp, 1, Integer::sum);
                  this.lastSeenMs.put(cp, System.currentTimeMillis());
               } else {
                  // Miss this scan → drop immediately (no linger flicker the other way)
                  this.streak.remove(cp);
                  this.pending.remove(cp);
                  this.lastSeenMs.remove(cp);
               }
            }

            // Publish only stable + in range
            Map<ChunkPos, HitInfo> published = new HashMap<>();
            for (Map.Entry<ChunkPos, Integer> e : this.streak.entrySet()) {
               ChunkPos cp = e.getKey();
               if (!inRange.contains(cp) && (Math.abs(cp.x - origin.x) > radius || Math.abs(cp.z - origin.z) > radius)) {
                  continue;
               }
               if (e.getValue() >= needStable) {
                  HitInfo hi = this.pending.get(cp);
                  if (hi != null) published.put(cp, hi);
               }
            }
            // drop far streaks
            long nowMs = System.currentTimeMillis();
            this.streak.keySet().removeIf(cp -> {
               if (Math.abs(cp.x - origin.x) > radius || Math.abs(cp.z - origin.z) > radius) return true;
               Long seen = this.lastSeenMs.get(cp);
               return seen == null || nowMs - seen > 2500L;
            });
            this.lastSeenMs.keySet().removeIf(cp -> !this.streak.containsKey(cp));
            // also force-drop published that left range
            this.pending.keySet().removeIf(cp -> !this.streak.containsKey(cp));

            this.lastThreshold = usedTh;
            this.hits = Collections.unmodifiableMap(published);
            SusAlert.onNewHits("67", this.hits, 0xFFFF5555);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private static final class ScanResult {
      double score;
      final List<String> reasons = new ArrayList<>();

      void addReason(String r) {
         if (!this.reasons.contains(r)) this.reasons.add(r);
      }

      String reasonString() {
         return String.join("+", this.reasons);
      }
   }

   private static ScanResult scoreChunk(
         World world, WorldChunk chunk, ChunkPos cp,
         boolean doAm, boolean doKelp, boolean doBamboo, boolean doBerries, boolean doVines, boolean doDrip,
         int minKelpH, int minBambooH
   ) {
      ScanResult sr = new ScanResult();
      int amBlocks = 0, clusters = 0;
      int kelpCols = 0, bambooCols = 0, berryMax = 0, vineN = 0, dripCols = 0;

      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      BlockPos.Mutable mut2 = new BlockPos.Mutable();
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx;
                  int wy = baseY + ly;
                  int wz = z0 + lz;

                  if (doAm && isAmethyst(st)) {
                     amBlocks++;
                     if (b == Blocks.AMETHYST_CLUSTER) clusters++;
                     continue;
                  }
                  if (doBerries && b == Blocks.SWEET_BERRY_BUSH) {
                     if (st.contains(SweetBerryBushBlock.AGE) && st.get(SweetBerryBushBlock.AGE) >= 3) berryMax++;
                     continue;
                  }
                  if (doVines && (b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) {
                     vineN++;
                     continue;
                  }
                  if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.KELP) || above.isOf(Blocks.KELP_PLANT)) continue;
                     int h = columnLength(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT);
                     if (h >= minKelpH) kelpCols++;
                     continue;
                  }
                  if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.BAMBOO) || above.isOf(Blocks.BAMBOO_SAPLING)) continue;
                     int h = columnLength(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING);
                     if (h >= minBambooH) bambooCols++;
                     continue;
                  }
                  if (doDrip && b == Blocks.POINTED_DRIPSTONE) {
                     mut.set(wx, wy + 1, wz);
                     if (world.getBlockState(mut).isOf(Blocks.POINTED_DRIPSTONE)) continue;
                     int h = columnLength(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.POINTED_DRIPSTONE);
                     if (h >= 5) dripCols++;
                  }
               }
            }
         }
      }

      // Weighted like 67
      if (doAm && amBlocks >= 4) {
         sr.score += Math.min(amBlocks, 32) * 6.0;
         sr.addReason("AM");
         if (clusters >= 2) {
            sr.score += clusters * 3.0;
            sr.addReason("CL");
         }
      }
      if (doKelp && kelpCols >= 1) {
         sr.score += Math.min(kelpCols, 6) * 2.0;
         sr.addReason("KELP");
      }
      if (doBamboo && bambooCols >= 1) {
         sr.score += Math.min(bambooCols, 6) * 2.0;
         sr.addReason("BAM");
      }
      if (doBerries && berryMax >= 2) {
         sr.score += Math.min(berryMax, 6) * 2.0;
         sr.addReason("BER");
      }
      if (doVines && vineN >= 24) {
         sr.score += Math.min(vineN / 4, 6) * 2.0;
         sr.addReason("VIN");
      }
      if (doDrip && dripCols >= 1) {
         sr.score += Math.min(dripCols, 5) * 2.0;
         sr.addReason("DRIP");
      }
      return sr;
   }

   private static int columnLength(World world, BlockPos.Mutable pos, Direction dir, Block... match) {
      int n = 0;
      for (int i = 0; i < 32; i++) {
         BlockState st = world.getBlockState(pos);
         boolean ok = false;
         for (Block b : match) {
            if (st.isOf(b)) { ok = true; break; }
         }
         if (!ok) break;
         n++;
         pos.move(dir);
      }
      return n;
   }

   private static boolean isAmethyst(BlockState st) {
      Block b = st.getBlock();
      return b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
         || b == Blocks.AMETHYST_CLUSTER
         || b == Blocks.SMALL_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.LARGE_AMETHYST_BUD;
   }


   /** Only draw chunks roughly in front of the camera (cuts lag + stale rear flags). */
   private static boolean facingCamera(Vec3d camPos, float yawDeg, ChunkPos cp) {
      double cx = (cp.x << 4) + 8.0;
      double cz = (cp.z << 4) + 8.0;
      double dx = cx - camPos.x;
      double dz = cz - camPos.z;
      double len2 = dx * dx + dz * dz;
      if (len2 < 4.0) return true; // always show under feet
      double len = Math.sqrt(len2);
      double yaw = Math.toRadians(yawDeg);
      // camera look on XZ: -sin(yaw), cos(yaw) in MC
      double lx = -Math.sin(yaw);
      double lz = Math.cos(yaw);
      double dot = (dx / len) * lx + (dz / len) * lz;
      return dot > -0.15; // slight behind still ok, full rear culled
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, HitInfo> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 120));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      GL11.glEnable(GL11.GL_BLEND);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      float yaw = camera.getYaw();
      for (ChunkPos cp : map.keySet()) {
         if (!facingCamera(cam, yaw, cp)) continue;
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      SUSChunkFinder self = INSTANCE;
      if (self == null || !self.isEnabled()) return;
      if (!self.showPercent.getValue() && !self.showReason.getValue()) return;

      Map<ChunkPos, HitInfo> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }

      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();
      boolean showPct = self.showPercent.getValue();
      boolean showR = self.showReason.getValue();

      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         HitInfo hi = e.getValue();
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;

         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = hi.percent;
         lp.reasons = hi.reasons == null ? "" : hi.reasons;

         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }

         if (now - lp.lastOkMs < 250L && lp.lastOkMs > 0) {
            float ty = lp.y - 6f;
            // Banner: 67
            String tag = "67";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f, ty, 0xFFFF5555);

            float lineY = ty + 10;
            if (showR && lp.reasons != null && !lp.reasons.isEmpty()) {
               String r = lp.reasons;
               int rw = FontRenderer.INSTANCE.getWidth(r);
               FontRenderer.INSTANCE.drawString(context, r, lp.x - rw / 2f + 1, lineY + 1, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, r, lp.x - rw / 2f, lineY, 0xFFFFCC88);
               lineY += 10;
            }
            if (showPct) {
               String pct = lp.percent + "%";
               int pw = FontRenderer.INSTANCE.getWidth(pct);
               int color = lp.percent >= 85 ? 0xFFFF5555 : (lp.percent >= 70 ? 0xFFFFAA00 : 0xFFFFFF55);
               FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, lineY + 1, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, lineY, color);
            }
         }
      }
      self.labelCache.keySet().removeIf(cp -> !keep.contains(cp));
   }
}
