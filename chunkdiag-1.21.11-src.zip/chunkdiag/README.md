# Chunk Diagnostic (Fabric 1.21.11, client-side)

## ก่อน build
1. ไปที่ https://fabricmc.net/develop เลือก Minecraft 1.21.11 แล้วดาวน์โหลด template
2. คัดลอกค่า yarn_mappings, loader_version, loom_version, fabric_version จาก template มาใส่ใน gradle.properties (แทนที่ <...>)
3. ถ้าโฟลเดอร์นี้ไม่มี gradlew ให้คัดลอก gradlew, gradlew.bat และโฟลเดอร์ gradle/ จาก template มาวางไว้

## Build
    ./gradlew build
ไฟล์ .jar อยู่ที่ build/libs/

## ติดตั้ง
วางไฟล์ .jar ใน mods/ ของ Fabric Loader 1.21.11 พร้อม Fabric API ให้ตรงเวอร์ชัน (client-side ไม่ต้องติดตั้งบนเซิร์ฟเวอร์)

## ปุ่มลัด
- M: เพิ่ม waypoint ที่ตำแหน่งปัจจุบัน
- H: เปิด/ปิด HUD

## ความหมายของค่าบน HUD
- loaded=false หรือ exists=false: chunk ยังไม่ถูกส่งมาที่ client
- Section@Y0: EMPTY ทั้งที่เห็นถ้ำ: section นั้นไม่มีบล็อกฝั่ง client มักแปลว่าเซิร์ฟไม่ได้ส่งข้อมูล
- Non-empty sections Y<0: 0/... ขณะที่ Y>=0 มีค่า: ข้อมูลฝั่งลึกหายไปทั้งหมด
- มี section ไม่ว่างแต่ยังมองไม่เห็น: ปัญหาการเรนเดอร์ ลองปิด Sodium/Iris/shader

## ข้อจำกัด
- ยังไม่ได้ compile ทดสอบจริง ชื่อ method บางตัวอาจต่างใน Yarn 1.21.11
- waypoint ไม่บันทึกถาวร หายเมื่อปิดเกม
