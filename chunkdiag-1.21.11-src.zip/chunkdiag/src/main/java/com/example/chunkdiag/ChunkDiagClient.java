package com.example.chunkdiag;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ChunkDiagClient implements ClientModInitializer {

    public record Waypoint(String name, double x, double y, double z) {}

    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
    private static final int SCAN_RADIUS_CHUNKS = 4;
    private static final int LINE_HEIGHT = 10;
    private static final int TEXT_COLOR = 0xFFFFFF;

    private static KeyBinding markKey;
    private static KeyBinding toggleKey;
    private static boolean hudVisible = true;

    @Override
    public void onInitializeClient() {
        markKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chunkdiag.mark",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                KeyBinding.Category.MISC
        ));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chunkdiag.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (markKey.wasPressed()) {
                addWaypoint(client);
            }
            while (toggleKey.wasPressed()) {
                hudVisible = !hudVisible;
            }
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (!hudVisible) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null || mc.player == null) {
                return;
            }
            renderDiagnostics(context, mc);
        });
    }

    private static void addWaypoint(MinecraftClient mc) {
        if (mc.player == null) {
            return;
        }
        PlayerEntity p = mc.player;
        WAYPOINTS.add(new Waypoint("WP" + (WAYPOINTS.size() + 1), p.getX(), p.getY(), p.getZ()));
    }

    private static void renderDiagnostics(DrawContext ctx, MinecraftClient mc) {
        ClientWorld world = mc.world;
        PlayerEntity p = mc.player;
        if (world == null || p == null) {
            return;
        }

        BlockPos pos = p.getBlockPos();
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;
        List<String> lines = new ArrayList<>();

        boolean loaded = world.getChunkManager().isChunkLoaded(cx, cz);
        WorldChunk current = getWorldChunk(world, cx, cz);
        lines.add("Chunk (" + cx + ", " + cz + ") loaded=" + loaded + " exists=" + (current != null));

        int minY = world.getBottomY();
        lines.add(String.format("World bottomY=%d  player Y=%.1f", minY, p.getY()));

        if (current != null) {
            ChunkSection[] sections = current.getSectionArray();
            int secIdx = current.getSectionIndex(pos.getY());
            lines.add("Section@playerY: " + describeSection(sections, secIdx));
            int idx0 = current.getSectionIndex(0);
            lines.add("Section@Y0: " + describeSection(sections, idx0));
            int idxNeg16 = current.getSectionIndex(-16);
            lines.add("Section@Y-16: " + describeSection(sections, idxNeg16));
        } else {
            lines.add("Section@playerY: no chunk");
            lines.add("Section@Y0: no chunk");
        }

        int nonEmptyLow = 0, nonEmptyHigh = 0, totalLow = 0, totalHigh = 0, missingChunks = 0;
        for (int dx = -SCAN_RADIUS_CHUNKS; dx <= SCAN_RADIUS_CHUNKS; dx++) {
            for (int dz = -SCAN_RADIUS_CHUNKS; dz <= SCAN_RADIUS_CHUNKS; dz++) {
                WorldChunk c = getWorldChunk(world, cx + dx, cz + dz);
                if (c == null) {
                    missingChunks++;
                    continue;
                }
                ChunkSection[] secs = c.getSectionArray();
                for (int i = 0; i < secs.length; i++) {
                    int secBottomY = minY + i * 16;
                    boolean nonEmpty = secs[i] != null && !secs[i].isEmpty();
                    if (secBottomY < 0) {
                        totalLow++;
                        if (nonEmpty) {
                            nonEmptyLow++;
                        }
                    } else {
                        totalHigh++;
                        if (nonEmpty) {
                            nonEmptyHigh++;
                        }
                    }
                }
            }
        }

        lines.add("Chunks missing in radius " + SCAN_RADIUS_CHUNKS + ": " + missingChunks);
        lines.add("Non-empty sections Y<0:  " + nonEmptyLow + "/" + totalLow);
        lines.add("Non-empty sections Y>=0: " + nonEmptyHigh + "/" + totalHigh);

        int blockLight = world.getLightLevel(LightType.BLOCK, pos);
        int skyLight = world.getLightLevel(LightType.SKY, pos);
        lines.add("Light block=" + blockLight + " sky=" + skyLight);

        for (Waypoint wp : WAYPOINTS) {
            lines.add(describeWaypoint(wp, p));
        }

        int y = 5;
        for (String line : lines) {
            ctx.drawTextWithShadow(mc.textRenderer, line, 5, y, TEXT_COLOR);
            y += LINE_HEIGHT;
        }
    }

    private static String describeSection(ChunkSection[] sections, int idx) {
        if (idx < 0 || idx >= sections.length) {
            return "OUT OF RANGE";
        }
        ChunkSection s = sections[idx];
        if (s == null) {
            return "NULL";
        }
        return s.isEmpty() ? "EMPTY" : "has blocks";
    }

    private static String describeWaypoint(Waypoint wp, PlayerEntity p) {
        double dx = wp.x() - p.getX();
        double dy = wp.y() - p.getY();
        double dz = wp.z() - p.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double rel = wrapDegrees(targetYaw - p.getYaw());
        String side = rel >= 0 ? "R" : "L";
        return String.format("%s: %.0f blocks, %.0f deg %s", wp.name(), dist, Math.abs(rel), side);
    }

    private static double wrapDegrees(double deg) {
        deg = deg % 360.0;
        if (deg > 180.0) {
            deg -= 360.0;
        }
        if (deg < -180.0) {
            deg += 360.0;
        }
        return deg;
    }

    private static WorldChunk getWorldChunk(ClientWorld world, int cx, int cz) {
        try {
            Chunk chunk = world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
            if (chunk instanceof WorldChunk wc) {
                return wc;
            }
        } catch (Throwable ignored) {
        }
        try {
            return world.getChunk(cx, cz);
        } catch (Throwable ignored) {
            return null;
        }
    }
}
