package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Port of Anubis 0.9.9.3 Prime Chunk Finder ideas:
 * - Flag chunks with amethyst sections that have unusually low block-light
 *   (possible dug-out geodes / player activity)
 * - Optional: lamp/redstone light blobs underground
 * - Bee/full-honey still available as secondary signal
 * Banner: PR
 */
public final class PrimeChunkFinder extends Module {
   public static PrimeChunkFinder INSTANCE;

   public final Setting<Integer> radius = new Setting<>("Radius", 6, 1, 16);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 4, 1, 20);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 8, 2, 24);
   public final Setting<Integer> displayY = new Setting<>("Display Y", 80, -64, 320);
   public final Setting<Integer> alpha = new Setting<>("Alpha", 55, 0, 255);
   public final Setting<Color> color = new Setting<>("Color", new Color(80, 200, 255, 55));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> amethystLowLight = new Setting<>("Amethyst Low Light", true);
   public final Setting<Boolean> undergroundLamps = new Setting<>("Underground Lamps", true);
   public final Setting<Boolean> beeSignal = new Setting<>("Bee Nest/Hive", true);
   public final Setting<Boolean> showLabel = new Setting<>("Show Label", true);
   public final Setting<Integer> maxAmLight = new Setting<>("Max Amethyst Light", 5, 0, 10);
   public final Setting<Integer> minLampY = new Setting<>("Min Lamp Y", -20, -64, 128);

   public static final class HitInfo {
      public final String reasons;
      public final int score;
      public HitInfo(String reasons, int score) {
         this.reasons = reasons;
         this.score = score;
      }
   }

   public volatile Map<ChunkPos, HitInfo> hits = Collections.emptyMap();
   private final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   public static final class LabelPos {
      public float x, y;
      public String reasons = "";
      public long lastOkMs;
   }

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick, cursor;

   public PrimeChunkFinder() {
      super("Prime Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.radius);
      this.addSetting(this.sensitivity);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.displayY);
      this.addSetting(this.alpha);
      this.addSetting(this.color);
      this.addSetting(this.outline);
      this.addSetting(this.amethystLowLight);
      this.addSetting(this.undergroundLamps);
      this.addSetting(this.beeSignal);
      this.addSetting(this.showLabel);
      this.addSetting(this.maxAmLight);
      this.addSetting(this.minLampY);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 4 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "prime-chunk");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int rad = this.radius.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();
      final boolean doAm = this.amethystLowLight.getValue();
      final boolean doLamp = this.undergroundLamps.getValue();
      final boolean doBee = this.beeSignal.getValue();
      final int maxAmL = this.maxAmLight.getValue();
      final int minLY = this.minLampY.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -rad; dx <= rad; dx++) {
         for (int dz = -rad; dz <= rad; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;
      final World world = mc.world;
      final Map<ChunkPos, HitInfo> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, HitInfo> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= rad && Math.abs(cp.z - origin.z) <= rad) {
            retained.put(cp, e.getValue());
         }
      }

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, HitInfo> next = new HashMap<>(retained);
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               int score = 0;
               List<String> reasons = new ArrayList<>();
               int x0 = cp.getStartX();
               int z0 = cp.getStartZ();
               BlockPos.Mutable mut = new BlockPos.Mutable();
               ChunkSection[] sections = wc.getSectionArray();
               int bottom = wc.getBottomY();

               int amLow = 0, lamps = 0, bees = 0;

               for (int si = 0; si < sections.length; si++) {
                  ChunkSection section = sections[si];
                  if (section == null || section.isEmpty()) continue;
                  int baseY = bottom + si * 16;

                  for (int lx = 0; lx < 16; lx += 2) {
                     for (int ly = 0; ly < 16; ly += 2) {
                        for (int lz = 0; lz < 16; lz += 2) {
                           BlockState st = section.getBlockState(lx, ly, lz);
                           Block b = st.getBlock();
                           int wx = x0 + lx, wy = baseY + ly, wz = z0 + lz;
                           mut.set(wx, wy, wz);

                           if (doAm && (b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
                                 || b == Blocks.AMETHYST_CLUSTER)) {
                              int bl = world.getLightLevel(LightType.BLOCK, mut);
                              if (bl <= maxAmL) amLow++;
                           }
                           if (doLamp && wy <= minLY) {
                              if (b == Blocks.REDSTONE_LAMP || b == Blocks.LANTERN || b == Blocks.SOUL_LANTERN
                                    || b == Blocks.TORCH || b == Blocks.WALL_TORCH
                                    || b == Blocks.SEA_LANTERN || b == Blocks.GLOWSTONE
                                    || b == Blocks.SHROOMLIGHT) {
                                 lamps++;
                              }
                           }
                           if (doBee && (b == Blocks.BEE_NEST || b == Blocks.BEEHIVE)) {
                              bees++;
                           }
                        }
                     }
                  }
               }

               if (amLow >= 3) { score += Math.min(amLow, 20); reasons.add("AM-L"); }
               if (lamps >= 2) { score += Math.min(lamps * 2, 16); reasons.add("LAMP"); }
               if (bees >= 1) { score += bees * 3; reasons.add("BEE"); }

               if (score >= sens && !reasons.isEmpty()) {
                  next.put(cp, new HitInfo(String.join("+", reasons), score));
               } else {
                  next.remove(cp);
               }
            }
            this.hits = Collections.unmodifiableMap(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, HitInfo> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.displayY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.color.getValue();
      int a = this.alpha.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : map.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      PrimeChunkFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showLabel.getValue()) return;
      Map<ChunkPos, HitInfo> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      double textY = self.displayY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();
      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.reasons = e.getValue().reasons;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 250L && lp.lastOkMs > 0) {
            String tag = "PR";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            float ty = lp.y - 6f;
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f, ty, 0xFF55DDFF);
            if (lp.reasons != null && !lp.reasons.isEmpty()) {
               int rw = FontRenderer.INSTANCE.getWidth(lp.reasons);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f + 1, ty + 11, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f, ty + 10, 0xFFAAEEFF);
            }
         }
      }
      self.labelCache.keySet().removeIf(c -> !keep.contains(c));
   }
}
